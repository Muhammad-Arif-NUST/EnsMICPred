function encodings = GapDipeptide400(fastas, g)
% ============================================================
% GapDipeptide400
% Computes g-gap dipeptide composition (400 features)
%
% Input:
%   fastas : Nx2 cell array {protein_name, sequence}
%   g      : gap size (0,1,2,...)
%
% Output:
%   encodings : Cell array (header + normalized features)
%
% Dimension:
%   400 features per gap
%
% ============================================================

AA = 'ACDEFGHIKLMNPQRSTVWY';
AA_num = length(AA);

%% -------- Header -------------------------------------------
header = {'name','sequence'};
for i = 1:AA_num
    for j = 1:AA_num
        header{end+1} = [AA(i) AA(j) '_g' num2str(g)];
    end
end

encodings = cell(size(fastas,1)+1,1);
encodings{1} = header;

%% -------- Feature Extraction -------------------------------
for f = 1:size(fastas,1)

    name = fastas{f,1};
    seq  = regexprep(fastas{f,2}, '-', '');

    code = {name, seq};
    countMat = zeros(AA_num, AA_num);
    total = 0;

    for i = 1:(length(seq) - g - 1)
        aa1 = seq(i);
        aa2 = seq(i + g + 1);

        idx1 = find(AA == aa1, 1);
        idx2 = find(AA == aa2, 1);

        if ~isempty(idx1) && ~isempty(idx2)
            countMat(idx1, idx2) = countMat(idx1, idx2) + 1;
            total = total + 1;
        end
    end

    % Normalize and flatten
    if total == 0
        featureVec = zeros(1, 400);
    else
        featureVec = reshape(countMat ./ total, 1, []);
    end

    encodings{f+1} = [code, num2cell(featureVec)];
end

end
